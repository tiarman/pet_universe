<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>Admin | Dashboard</title>

    <meta content="Ours" name="author" />
    <meta content="RAST" name="company" />
    <meta content="RAST" name="description" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('fav.jpg')); ?>" type="image/png">
    <link href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/admin/css/icons.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/admin/css/style.css')); ?>" rel="stylesheet" type="text/css">
    
    
    

    <style>
        body {
            font-size: 14px;
        }

        label {
            font-size: 12px;
        }

        .form-control {
            font-size: 14px;
        }
    </style>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/custom.css')); ?>">
    <?php echo $__env->yieldContent('stylesheet'); ?>
</head>

<body class="fixed-left">
    <!-- Loader -->
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>

    <div id="wrapper">
        <!-- ========== Left Sidebar Start ========== -->
        <div class="left side-menu">

            <!-- LOGO -->
            <?php if($logo): ?>
            <div class="topbar-left">
                <div class="text-center" style="padding-right: 35px">
                    <a href="<?php echo e(route('home')); ?>" class="logo">
                        <img style="background: whitesmoke;display: unset"
                        
                            src="<?php echo e($logo->value); ?>" height="50" alt="logo"></a>
                            
                </div>
            </div>
            <?php endif; ?>
            <div class="sidebar-inner slimscrollleft">
                <div id="sidebar-menu">
                    <ul>
                        <li class="menu-title">Menu</li>
                        
                        
                        
                        
                        

                        <li class="has_sub">
                            <a class="waves-effect"><i class="mdi mdi-account-multiple"></i><span> Orders <span
                                        class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                            <ul class="list-unstyled">
                                <li><a href="<?php echo e(route('order.list')); ?>">List of Order</a></li>
                            </ul>
                        </li>
                        <?php if(\App\Helper\CustomHelper::canView('Create User|Manage User|Delete User|View User|List Of User', 'Super Admin')): ?>
                            <li class="has_sub">
                                <a class="waves-effect"><i class="mdi mdi-account-multiple"></i><span> Users <span
                                            class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                                <ul class="list-unstyled">
                                    <?php if(\App\Helper\CustomHelper::canView('Create User', 'Super Admin')): ?>
                                        <li><a href="<?php echo e(route('user.create')); ?>">Create User</a></li>
                                    <?php endif; ?>
                                    <?php if(\App\Helper\CustomHelper::canView('Manage User|Delete User|View User|List Of User', 'Super Admin')): ?>
                                        <li><a href="<?php echo e(route('user.list')); ?>">List of User</a></li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        <?php endif; ?>

                        <?php if(\App\Helper\CustomHelper::canView('Create Role|Manage Role|Delete Role|View Role|List Of Role', 'Super Admin')): ?>
                            <li class="has_sub">
                                <a class="waves-effect"><i class="mdi mdi-lock-open"></i><span> Roles <span
                                            class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                                <ul class="list-unstyled">
                                    <?php if(\App\Helper\CustomHelper::canView('Create Role', 'Super Admin')): ?>
                                        <li><a href="<?php echo e(route('role.create')); ?>">Create Role</a></li>
                                    <?php endif; ?>
                                    <?php if(\App\Helper\CustomHelper::canView('Manage Role|Delete Role|View Role|List Of Role', 'Super Admin')): ?>
                                        <li><a href="<?php echo e(route('role.list')); ?>">List of Role</a></li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        <?php endif; ?>
                        <?php if(\App\Helper\CustomHelper::canView('Manage Permission', 'Super Admin')): ?>
                            <li><a href="<?php echo e(route('permission.manage')); ?>" class="waves-effect">
                                    <i class="mdi mdi-block-helper"></i>
                                    <span> Permission</span>
                                </a></li>
                        <?php endif; ?>



                        <?php if(
                            \App\Helper\CustomHelper::canView(
                                'Create Category|Manage Category|Delete Category|View Category|List Of Category',
                                'Super Admin')): ?>
                            <li><a href="<?php echo e(route('category.list')); ?>" class="waves-effect">
                                    <i class="mdi mdi-image-album"></i>
                                    <span> Categories</span>
                                </a></li>
                        <?php endif; ?>


                        <?php if(
                            \App\Helper\CustomHelper::canView(
                                'Create Category|Manage Category|Delete Category|View Category|List Of Category',
                                'Super Admin')): ?>
                            <li><a href="<?php echo e(route('subcategory.list')); ?>" class="waves-effect">
                                    <i class="mdi mdi-certificate"></i>
                                    <span> Sub Categories</span>
                                </a></li>
                        <?php endif; ?>

                        <?php if(
                            \App\Helper\CustomHelper::canView(
                                'Create Category|Manage Category|Delete Category|View Category|List Of Category',
                                'Super Admin')): ?>
                            <li><a href="<?php echo e(route('slider.list')); ?>" class="waves-effect">
                                    <i class="mdi mdi-image-album"></i>
                                    <span> Slider</span>
                                </a></li>
                        <?php endif; ?>


                        


                        



                        <?php if(
                            \App\Helper\CustomHelper::canView(
                                'Create Animal|Manage Animal|Delete Animal|View Animal|List Of Animal',
                                'Super Admin')): ?>
                            <li class="has_sub">
                                <a class="waves-effect"><i class="mdi mdi-cat"></i><span>Animal<span
                                            class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                                <ul class="list-unstyled">
                                    <?php if(\App\Helper\CustomHelper::canView('Create Animal', 'Super Admin')): ?>
                                        <li><a href="<?php echo e(route('animal.create')); ?>">Create Animal</a></li>
                                    <?php endif; ?>
                                    <?php if(\App\Helper\CustomHelper::canView('Manage Animal|Delete Animal|View Animal|List Of Animal', 'Super Admin')): ?>
                                        <li><a href="<?php echo e(route('animal.list')); ?>">List of Animal</a></li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        <?php endif; ?>


                        <?php if(
                            \App\Helper\CustomHelper::canView(
                                'Create Setting|Manage Setting|Delete Setting|View Setting|List Of Setting',
                                'Super Admin')): ?>
                            <li class="has_sub">
                                <a class="waves-effect"><i class="mdi mdi-settings"></i><span>Setting<span
                                            class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                                <ul class="list-unstyled">
                                    <?php if(\App\Helper\CustomHelper::canView('Create Setting', 'Super Admin')): ?>
                                        <li><a href="<?php echo e(route('setting.create')); ?>">Create Setting</a></li>
                                    <?php endif; ?>
                                    <?php if(\App\Helper\CustomHelper::canView('Manage Setting|Delete Setting|View Setting|List Of Setting', 'Super Admin')): ?>
                                        <li><a href="<?php echo e(route('setting.list')); ?>">List of Setting</a></li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        <?php endif; ?>
                        

                        


                        <?php if(
                            \App\Helper\CustomHelper::canView(
                                'Create SiteReview|Manage SiteReview|Delete SiteReview|View SiteReview|List Of SiteReview',
                                'Customer')): ?>
                            <li><a href="<?php echo e(route('sitereview.list')); ?>" class="waves-effect">
                                    <i class="mdi mdi-image-album"></i>
                                    <span>Testimonial</span>
                                </a></li>
                        <?php endif; ?>
                          <?php if(
                            \App\Helper\CustomHelper::canView(
                                'Create SiteReview|Manage SiteReview|Delete SiteReview|View SiteReview|List Of SiteReview',
                                'Super Admin')): ?>
                            <li><a href="<?php echo e(route('sitereview.list_admin')); ?>" class="waves-effect">
                                    <i class="mdi mdi-image-album"></i>
                                    <span> Manage Testimonials</span>
                                </a></li>
                        <?php endif; ?>






                    </ul>
                </div>
                <div class="clearfix"></div>
            </div> <!-- end sidebarinner -->
        </div>
        <!-- Left Sidebar End -->

        <!-- Start right Content here -->
        <div class="content-page">

            <!-- Start content -->
            <div class="content">

                <!-- Top Bar Start -->
                <div class="topbar">

                    <nav class="navbar-custom">
                        <!-- Search input -->
                        <div class="search-wrap" id="search-wrap">
                            <div class="search-bar">
                                <input class="search-input" type="search" placeholder="Search" />
                                <a href="#" class="close-search toggle-search" data-target="#search-wrap">
                                    <i class="mdi mdi-close-circle"></i>
                                </a>
                            </div>
                        </div>

                        <ul class="float-right mb-0 list-inline">
                            <!-- Fullscreen -->
                            <li class="list-inline-item dropdown notification-list hidden-xs-down">
                                <a class="nav-link waves-effect" href="#" id="btn-fullscreen">
                                    <i class="mdi mdi-fullscreen noti-icon"></i>
                                </a>
                            </li>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            <li class="list-inline-item dropdown notification-list">
                                <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user"
                                    data-toggle="dropdown" href="#" role="button" aria-haspopup="false"
                                    aria-expanded="false">
                                    <img src="<?php echo e(auth()->user()->profile_photo_url); ?>" alt="user"
                                        class="object-cover w-8 h-8 rounded-full">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><i
                                            class="dripicons-user text-muted"></i>
                                        Profile</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"><i
                                            class="dripicons-exit text-muted"></i>
                                        Logout</a>
                                </div>
                            </li>
                        </ul>
                        <!-- Page title -->
                        <ul class="mb-0 list-inline menu-left">
                            <li class="list-inline-item">
                                <button type="button" class="button-menu-mobile open-left waves-effect">
                                    <i class="ion-navicon"></i>
                                </button>
                            </li>
                            <li class="hide-phone list-inline-item app-search">
                                <h3 class="page-title">Dashboard</h3>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </nav>
                </div>
                <!-- Top Bar End -->

                <div class="page-content-wrapper">
                    <?php echo $__env->yieldContent('content'); ?>
                </div> <!-- Page content Wrapper -->
            </div>
            <footer class="footer">
                © 2023 <?php echo e(env('APP_NAME')); ?>

                <span class="text-muted hidden-xs-down pull-right">Developed & Maintained by <a href=""
                        target="_blank">OURS</a></span>
            </footer>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/modernizr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.slimscroll.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/waves.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.nicescroll.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.scrollTo.min.js')); ?>"></script>
    


    <!-- App js -->
    <script src="<?php echo e(asset('assets/admin/js/app.js')); ?>"></script>
    
    <?php echo \Livewire\Livewire::scripts(); ?>



    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

        })
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\All Projects\2023\pet_universe\resources\views/layouts/admin.blade.php ENDPATH**/ ?>