


<?php $__env->startSection('stylesheet'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/site/css/custom.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="conatiner main-container">
        <div class="login-container  py-5 ">
            <div class="card login-card">
                <div class="card-body login-card-body">
                    
                    <div class="pl-3 pr-3 pb-3">
                                <h3 class="m-2 text-center border-bottom pb-5" style="color:rgb(246,171,73);">Login</h3>
                            
                        <?php if(session()->has('status')): ?>
                            <?php echo session()->get('status'); ?>

                        <?php endif; ?>
                        <form class="form-horizontal mt-5" action="<?php echo e(route('login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="form-label" for="text"> <i class="fa fa-duotone fa-envelope icon login-icon"></i> Email</label>
                                <div class="d-flex">
                                    <input type="email" name="email" id="email" placeholder="Enter Your Email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('email')); ?>" required>
                                    <span class="mt-1 "></span>
                                </div>

                                <span class="spin"></span>
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($errors->first('username')); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group mt-3">
                                <label class="form-label" for="password"> <i class="fa fa-regular fa-key icon login-icon"></i> Password</label>
                                <div class="d-flex">
                                  <input type="password" name="password" id="password" placeholder="Enter Your Password" autocomplete="off"
                                         class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('password')); ?>" required>
                                         <span toggle="#password-field" class="mt-1 "><i style="margin-left: -23px" class="fa fa-fw fa-eye field_icon toggle-password"></i></span>
                    
                                  
                                </div>

                                <span class="spin"></span>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($errors->first('password')); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <a href="<?php echo e(route('password.request')); ?>" class=" pt-3 mx-auto">Forget Password?</a>
                            </div>

                            <div class="form-group row mt-4">
                                <div class="col-sm-12 text-right">
                                    <button style="background-color:rgb(246,171,73);"
                                        class="btn text-light w-100 waves-effect waves-light" type="submit">Log In</button>
                                </div>
                                <a href="<?php echo e(route('register')); ?>"
                                        class="pt-3 text-center">New User? Register Now</a>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>


<script>
    $("body").on('click', '.toggle-password', function() {
        $(this).toggleClass("fa-eye fa-eye-slash");
        var input = $("#password");
        if (input.attr("type") === "password") {
          input.attr("type", "text");
        } else {
          input.attr("type", "password");
        }
      
      });
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\2023\pet_universe\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>