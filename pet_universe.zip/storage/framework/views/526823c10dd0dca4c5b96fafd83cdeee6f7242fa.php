

<?php $__env->startSection('stylesheet'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <section class="panel">
                        <header class="panel-heading">
                            <h2 class="panel-title">Create New Category</h2>
                        </header>
                        <div class="panel-body">
                            <?php if(\App\Helper\CustomHelper::canView('List Of User', 'Super Admin')): ?>
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-xl-12 text-right mb-3">
                                        <a href="<?php echo e(route('category.list')); ?>" class="brn btn-success btn-sm">List Of
                                            Categories</a>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(session()->has('status')): ?>
                                <?php echo session()->get('status'); ?>

                            <?php endif; ?>
                            
                                <section class="content">
                                    <div class="container-fluid">
                                        <!-- Info boxes -->
                                        <div class="row">
                                            <div class="col-4">
                                                <div class="card card-primary">
                                                    <div class="card-header">
                                                        <h3 class="card-title">Aamarpay Payment gateway</h3>
                                                    </div>
                                                    <!-- /.card-header -->
                                                    <!-- form start -->
                                                    <form role="form" action="<?php echo e(route('paymentgatway.update.aamarpay')); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($aamarpay->id); ?>">
                                                        <div class="card-body">
                                                            <div class="form-group">
                                                                <label for="exampleInputEmail1">StoreID</label>
                                                                <input type="text" class="form-control" name="store_id"
                                                                    value="<?php echo e($aamarpay->store_id); ?>" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="exampleInputEmail1">Signature KEY</label>
                                                                <input type="text" class="form-control"
                                                                    name="signature_key"
                                                                    value="<?php echo e($aamarpay->signature_key); ?>" required>
                                                            </div>
                                                        </div>
                                                        <!-- /.card-body -->
                                                        <div class="card-footer">
                                                        <button type="submit" class="btn btn-success">Update</button>
                                                        
                                                        </div>
                            </form>
                        </div> </div>
                        </div>
                </div>
                </section>
                

                <div class="row mt-4">
                    <div class="col-sm-12 text-right">
                        <button class="btn btn-danger btn-sm" type="submit">Submit</button>
                    </div>
                </div>
                
            </div>
            </section>
        </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\2023\pet_universe\resources\views/admin/bdpayment_getway/edit.blade.php ENDPATH**/ ?>