

<?php $__env->startSection('stylesheet'); ?>
  <!-- DataTables -->

  <link href="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"
        type="text/css"/>
  <link href="<?php echo e(asset('assets/admin/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet"
        type="text/css"/>

  <link href="<?php echo e(asset('assets/admin/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet"
        type="text/css"/>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <section class="panel">

            <div class="text-center">
                <span class="btn btn-sm btn-primary btn-add" style="cursor: pointer"
                 title="Delete"><i class="fa fa-plus-circle">
                    <span> Add Review <span class="pull-right"></span> </span></i></span>
            </div>

              <div class="modal fade" id="addModel" tabindex="-1" role="dialog" aria-labelledby="addModel"
              aria-hidden="true">
           <div class="modal-dialog modal-dialog-centered" role="document">
             <div class="modal-content">
               <div class="modal-header">
                 <h4>Add Review</h4>
               </div>
               <div class="modal-body">
                <form action="<?php echo e(route('sitereview.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label class="control-label">Name <span class="text-danger">*</span></label>
                          <input type="text" name="name" placeholder="name" value="<?php echo e(old('name')); ?>"
                                 class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                          
                          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <strong class="text-danger"><?php echo e($errors->first('name')); ?></strong>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>



                      <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">Image <label class="text-danger">*</label></label>
                            <input type="file" name="image"  placeholder="Review image" value="<?php echo e(old('image')); ?>"
                                   class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger"><?php echo e($errors->first('image')); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    </div>

                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label class="control-label">Designation<span class="text-danger">*</span></label>
                          <input type="text" name="designation" placeholder="designation No" value="<?php echo e(old('designation')); ?>"
                                 class="form-control <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                          <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <strong class="text-danger"><?php echo e($errors->first('designation')); ?></strong>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                    </div>
                    
                    
                    <div class="row">
                      <div class="col-sm-12">
                          <div class="form-group">
                              <label class="control-label">Comment</label>
                              <textarea name="comment" class="form-control <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3"><?php echo e(old('comment')); ?></textarea>
                              <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <strong class="text-danger"><?php echo e($errors->first('comment')); ?></strong>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                      </div>
                  </div>

                    <div class="row mt-4">
                      <div class="col-sm-12 text-right">
                        <div class="modal-footer">
                        <button class="btn btn-danger btn-sm" type="submit">Submit</button>
                    </div>
                      </div>
                    </div>
                  </form>


               </div>



             </div>
           </div>
         </div>




            <header class="panel-heading mt-5">
              <h2 class="panel-title">List of Review</h2>

            </header>
            <div class="panel-body">
              <?php if(session()->has('status')): ?>
                <?php echo session()->get('status'); ?>

              <?php endif; ?>

              
              
              <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                     cellspacing="0" width="100%" style="font-size: 14px">

                <thead>
                <tr>
                  <th width="10">#</th>
                  <th>Name</th>
                  <th>Designation</th>
                  <th>Image</th>
                  <th width="200">Created At</th>
                  <?php if(\App\Helper\CustomHelper::canView('Manage User|Delete User', 'Super Admin')): ?>
                    <th class="hidden-phone" width="40">Option</th>
                  <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="<?php if(($key%2) == 0): ?>gradeX <?php else: ?> gradeC <?php endif; ?>">
                    <td class="p-1"><?php echo e(($key+1)); ?></td>
                    <td class="p-1 text-capitalize"><?php echo e($val->name); ?></td>
                    <td class="p-1"><?php echo e($val->designation); ?></td>
                    <td class="p-1"><img src="<?php echo e(asset($val->image)); ?>" style="height: 50px;"></td>
                    <td width="200" class="p-1"><?php echo e(date('F d, Y h:i A', strtotime($val->created_at))); ?></td>



                    <?php if(\App\Helper\CustomHelper::canView('Manage User|Delete User', 'Super Admin')): ?>
                      <td class="center hidden-phone p-1" width="100">
                        
                        <?php if(\App\Helper\CustomHelper::canView('Manage User', 'Super Admin')): ?>
                        <a href="<?php echo e(route('sitereview.manage', $val->id)); ?>" class="btn btn-sm btn-success" title="Edit"> <i
                            class="fa fa-edit"></i> </a>
                      <?php endif; ?>
                        <?php if(\App\Helper\CustomHelper::canView('Delete User', 'Super Admin')): ?>
                          <span class="btn btn-sm btn-danger btn-delete delete_<?php echo e($val->id); ?>" style="cursor: pointer"
                                data-id="<?php echo e($val->id); ?>" title="Delete"><i
                              class="fa fa-trash-o"></i></span>
                        <?php endif; ?>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              
            </div>
          </section>
        </div>
      </div>
    </div>
  </div>



  <div class="modal fade" id="userDeleteModal" tabindex="-1" role="dialog" aria-labelledby="userDeleteModal"
       aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4>Delete Review</h4>
        </div>
        <div class="modal-body">
          <strong>Are you sure to delete this Review?</strong>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">No</button>
          <button type="button" class="btn btn-success btn-sm yes-btn">Yes</button>
        </div>
      </div>
    </div>
  </div>







  
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
  <!-- Required datatable js -->
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
  <!-- Buttons examples -->
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/jszip.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/pdfmake.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/vfs_fonts.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.html5.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.print.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
  <!-- Responsive examples -->
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>


  <script>

    $(document).ready(function () {
       $('#datatable-buttons').DataTable();

      // var table = $('#datatable-buttons').DataTable({
      //   lengthChange: false,
      //   buttons: ['copy', 'excel', 'pdf', 'colvis']
      // });
      //
      // table.buttons().container()
      //   .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');


      


      $(document).on('click', '.yes-btn', function () {
        var pid = $(this).data('id');
        var $this = $('.delete_' + pid)
        $.ajax({
          url: "<?php echo e(route('sitereview.destroy')); ?>",
          method: "delete",
          dataType: "html",
          data: {id: pid},
          success: function (data) {
            if (data === "success") {
              $('#userDeleteModal').modal('hide')
              $this.closest('tr').css('background-color', 'red').fadeOut();
            }
          }
        });
      })

      $(document).on('click', '.btn-delete', function () {
        var pid = $(this).data('id');
        $('.yes-btn').data('id', pid);
        $('#userDeleteModal').modal('show')
      });


      $(document).on('click', '.btn-add', function () {
        $('#addModel').modal('show')
      });


      $(document).on('click', '.btn-manage', function () {
        var id = $(this).data('id');
        
        var url = '<?php echo e(route("sitereview.manage", ":id")); ?>';
        url = url.replace(':id', id);
        

  $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                // Populate the modal with the retrieved data
                $('#sliderId').val(response.id);
                $('#sliderTitle').val(response.title);
                $('#sliderSubTitle').val(response.sub_title);
                // Populate other fields accordingly

                // Show the modal
                $('#manageModel').modal('show');
            },
            error: function(xhr, status, error) {
                // Handle the error if necessary
                console.log(error);
            }
        });
    });

      });

  </script>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\2023\pet_universe\resources\views/admin/sitereview/list.blade.php ENDPATH**/ ?>