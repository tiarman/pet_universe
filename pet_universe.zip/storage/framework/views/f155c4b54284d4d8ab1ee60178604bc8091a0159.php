
<?php $__env->startSection('stylesheet'); ?>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Area Start -->
    <div class="section breadcrumb-area bg-bright">
        <div class="container">
            <div class="row">
                <div class="text-center col-12">
                    <div class="breadcrumb-wrapper">
                        <h2 class="breadcrumb-title">Checkout</h2>
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li>checkout</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End -->

    <!-- Shopping Cart Section Start -->
    <div class="section section-margin">
        <?php if(session()->has('status')): ?>
            <div style="text-align: center; color: green; font-size: 20px">
                <?php echo session()->get('status'); ?>

            </div>
        <?php endif; ?>

        <?php if(session('message')): ?>
    <script>
        Swal.fire({
            icon: '<?php echo e(session('alert-type', 'info')); ?>',
            title: '<?php echo e(session('message')); ?>',
            showConfirmButton: false,
            timer: 1500
        });
    </script>
<?php endif; ?>
        <div class="container">

            <div class="row">
                <div class="col-12">

                    <!-- Cart Table Start -->
                    <div class="cart-table table-responsive">
                        <table class="table table-bordered">

                            <!-- Table Head Start -->
                            <thead>
                                <tr>
                                    <th class="pro-thumbnail">Image</th>
                                    <th class="pro-title">Product</th>
                                    <th class="pro-price">Price</th>
                                    <th class="pro-quantity">Quantity</th>
                                    <th class="pro-subtotal">Total</th>
                                    <th class="pro-remove">Remove</th>
                                </tr>
                            </thead>
                            <!-- Table Head End -->

                            <!-- Table Body Start -->



                            <tbody>
                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td class="pro-thumbnail"><a href="#"><img style="height: 50px; width: 50px"
                                                    class="fit-image" src="<?php echo e(asset($val->options->image)); ?>"
                                                    alt="Product" /></a></td>
                                        <td class="pro-title"><a
                                                href="<?php echo e(route('animal_details', $val->name)); ?>"><?php echo e($val->name); ?></a>
                                        </td>
                                        <td class="pro-price"><span><?php echo e($val->price); ?></span></td>
                                        <td class="pro-quantity">
                                            <div class="quantity">
                                                <div class="cart-plus-minus">
                                                    <input class="cart-plus-minus-box" value="<?php echo e($val->qty); ?>"
                                                        type="text">
                                                    <div class="dec qtybutton">-</div>
                                                    <div class="inc qtybutton">+</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="pro-subtotal"><span>৳<?php echo e($val->subtotal); ?></span></td>
                                        <form action="<?php echo e(route('shopping.remove', $val->id)); ?>" method="post"
                                            enctype="multipart/form-data">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            
                                            <td class="pro-remove"><button href="#"><i class="ti-trash"></i></button>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                            <!-- Table Body End -->

                        </table>
                    </div>
                    <!-- Cart Table End -->

                    <!-- Cart Button Start -->
                    <div class="cart-button-section mb-n4">

                        <!-- Cart Button left Side Start -->
                        <div class="mb-4 cart-btn-lef-side">
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-gray-deep btn-hover-primary">Continue
                                Shopping</a>
                            
                        </div>
                        <!-- Cart Button left Side End -->

                        <!-- Cart Button Right Side Start -->
                        <div class="mb-4 cart-btn-right-right">
                            <a href="<?php echo e(route('paymentCheckout')); ?>" class="btn btn-gray-deep btn-hover-primary">Proceed To Checkout</a>
                        </div>
                        <!-- Cart Button Right Side End -->

                    </div>
                    <!-- Cart Button End -->

                </div>
            </div>

            

        </div>
    </div>
    <!-- Shopping Cart Section End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://cdnjs .cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript">
        //store coupon ajax call
        $('#add_to_cart').submit(function(e) {
            e.preventDefault();
            $('.loading').removeClass('d-none');
            var url = $(this).attr('action');
            var request = $(this).serialize();
            $.ajax({
                url: url,
                type: 'post',
                async: false,
                data: request,
                success: function(data) {
                    toastr.success(data);
                    $('#add_to_cart')[e].reset();
                    $('.loading').addClass('d-none');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\All Projects\2023\pet_universe\resources\views/site/cart_page.blade.php ENDPATH**/ ?>